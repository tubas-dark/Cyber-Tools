# DarkBy

Script de utilidades feito em Python, com funcionalidades como ping, geolocalização, simulação de velocidade MS e banners personalizados.

## Instalação no Termux

```bash
pkg update && pkg upgrade -y
pkg install python git -y
git clone https://github.com/darkrootdev/DarkBy.git
cd DarkBy
pip install -r requirements.txt
python DarkBy.py

```bash
git clone https://github.com/dark7scar/DarkBy.git

# DarkByCyber
